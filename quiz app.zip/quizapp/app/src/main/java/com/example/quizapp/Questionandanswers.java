package com.example.quizapp;

public class Questionandanswers {

    public static String Question[]={
            "Best Android Faculty?",
            "Best Language?",
            "Which is Green City?"
    };
    public static String Choices[][]={
            {"Gaurav","NavneetSheoran","vikash","omkar"},
            {"Java","Kotlin","C++","Python"},
            {"Mumbai","Pune","Delhi","Chandigarh"}

    };
    public static String correctanswers[]={
            "NavneetSheoran",
            "Java",
            "Chandigarh"
    };
}
